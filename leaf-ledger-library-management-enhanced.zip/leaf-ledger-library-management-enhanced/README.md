# Leaf Library — Interactive Library Management System

React + Vite frontend-only library workspace.

## Run locally

1. Extract the ZIP and open the folder in VS Code.
2. Open Terminal in the project folder.
3. Run `npm install`.
4. Run `npm run dev` and open the localhost URL shown by Vite.

## Interactive features

- Dashboard overview with live collection and circulation counts
- Book collection: add, edit, delete, search, category filter, grid/list views
- Book indexing: unique accession numbers (LIB-0001 format), searchable accession register, shelf location and ISBN lookup, auto-assign missing indexes
- Members: register, edit and search member records
- Circulation: checkout books, calculate a 7-day due date, return books and update inventory/member counts
- Insights: collection category and availability summaries
- Responsive desktop/mobile interface
- Browser LocalStorage persistence; demo seed data included

This is a frontend-only project. It does not require a backend or database server. Data is stored in the browser on the device where it is used.
