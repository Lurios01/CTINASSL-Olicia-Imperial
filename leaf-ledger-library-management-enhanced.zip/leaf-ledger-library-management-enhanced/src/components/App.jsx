import React, { useEffect, useMemo, useState } from "react";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  ArrowLeftRight,
  ChartNoAxesCombined,
  ListOrdered,
  Search,
  Plus,
  ChevronDown,
  Bell,
  Menu,
  X,
  LibraryBig,
  CalendarDays,
  Bookmark,
  Clock3,
  CheckCircle2,
  AlertCircle,
  Filter,
  MoreHorizontal,
  Trash2,
  Pencil,
  RotateCcw,
  ArrowUpRight,
  BookPlus,
  UserPlus,
  Grid2X2,
  List,
  LogOut,
} from "lucide-react";
const seedBooks = [
  {
    id: 1,
    indexNo: "LIB-0001",
    title: "The Design of Everyday Things",
    author: "Don Norman",
    category: "Design",
    isbn: "9780465050659",
    copies: 8,
    available: 5,
    shelf: "A-12",
    color: "sage",
    year: 2013,
  },
  {
    id: 2,
    indexNo: "LIB-0002",
    title: "Norwegian Wood",
    author: "Haruki Murakami",
    category: "Fiction",
    isbn: "9780375704024",
    copies: 6,
    available: 2,
    shelf: "F-08",
    color: "rose",
    year: 1987,
  },
  {
    id: 3,
    indexNo: "LIB-0003",
    title: "The Pragmatic Programmer",
    author: "David Thomas",
    category: "Technology",
    isbn: "9780135957059",
    copies: 5,
    available: 0,
    shelf: "T-03",
    color: "blue",
    year: 2019,
  },
  {
    id: 4,
    indexNo: "LIB-0004",
    title: "Before the Coffee Gets Cold",
    author: "Toshikazu Kawaguchi",
    category: "Fiction",
    isbn: "9781335430991",
    copies: 7,
    available: 4,
    shelf: "F-11",
    color: "gold",
    year: 2015,
  },
  {
    id: 5,
    indexNo: "LIB-0005",
    title: "Steal Like an Artist",
    author: "Austin Kleon",
    category: "Art",
    isbn: "9780761169253",
    copies: 4,
    available: 3,
    shelf: "A-06",
    color: "lavender",
    year: 2012,
  },
  {
    id: 6,
    indexNo: "LIB-0006",
    title: "Atomic Habits",
    author: "James Clear",
    category: "Self-help",
    isbn: "9780735211292",
    copies: 9,
    available: 7,
    shelf: "S-02",
    color: "peach",
    year: 2018,
  },
  {
    id: 7,
    indexNo: "LIB-0007",
    title: "Educated",
    author: "Tara Westover",
    category: "Biography",
    isbn: "9780399590504",
    copies: 3,
    available: 1,
    shelf: "B-02",
    color: "blue",
    year: 2018,
  },
  {
    id: 8,
    indexNo: "LIB-0008",
    title: "The Creative Act",
    author: "Rick Rubin",
    category: "Art",
    isbn: "9780593652886",
    copies: 4,
    available: 4,
    shelf: "A-09",
    color: "sage",
    year: 2023,
  },
];
const seedMembers = [
  {
    id: "MB-1042",
    name: "Mikaela Santos",
    email: "mikaela.s@email.com",
    joined: "Oct 12, 2026",
    borrowed: 2,
  },
  {
    id: "MB-1043",
    name: "Daniel Reyes",
    email: "daniel.r@email.com",
    joined: "Oct 18, 2026",
    borrowed: 1,
  },
  {
    id: "MB-1044",
    name: "Andrea Cruz",
    email: "andrea.c@email.com",
    joined: "Oct 21, 2026",
    borrowed: 0,
  },
  {
    id: "MB-1045",
    name: "Gabriel Lim",
    email: "gabriel.l@email.com",
    joined: "Nov 02, 2026",
    borrowed: 1,
  },
];
const seedLoans = [
  {
    id: "LN-2081",
    bookId: 2,
    memberId: "MB-1042",
    borrowed: "Nov 08, 2026",
    due: "Nov 15, 2026",
    status: "Borrowed",
  },
  {
    id: "LN-2080",
    bookId: 3,
    memberId: "MB-1043",
    borrowed: "Oct 29, 2026",
    due: "Nov 05, 2026",
    status: "Overdue",
  },
  {
    id: "LN-2079",
    bookId: 4,
    memberId: "MB-1045",
    borrowed: "Nov 06, 2026",
    due: "Nov 13, 2026",
    status: "Borrowed",
  },
  {
    id: "LN-2078",
    bookId: 1,
    memberId: "MB-1042",
    borrowed: "Oct 22, 2026",
    due: "Oct 29, 2026",
    status: "Returned",
  },
];
const get = (k, v) => {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? v;
  } catch {
    return v;
  }
};
const initials = (n) =>
  n
    .split(" ")
    .map((x) => x[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
function App() {
  const [books, setBooks] = useState(() =>
      get("leaf-books", seedBooks).map((b, i) => ({
        ...b,
        indexNo: b.indexNo || `LIB-${String(i + 1).padStart(4, "0")}`,
      })),
    ),
    [members, setMembers] = useState(() => get("leaf-members", seedMembers)),
    [loans, setLoans] = useState(() => get("leaf-loans", seedLoans));
  const [tab, setTab] = useState("Overview"),
    [query, setQuery] = useState(""),
    [filter, setFilter] = useState("All"),
    [modal, setModal] = useState(null),
    [toast, setToast] = useState(""),
    [mobile, setMobile] = useState(false),
    [view, setView] = useState("grid");
  useEffect(
    () => localStorage.setItem("leaf-books", JSON.stringify(books)),
    [books],
  );
  useEffect(
    () => localStorage.setItem("leaf-members", JSON.stringify(members)),
    [members],
  );
  useEffect(
    () => localStorage.setItem("leaf-loans", JSON.stringify(loans)),
    [loans],
  );
  useEffect(() => {
    if (toast) {
      let t = setTimeout(() => setToast(""), 2500);
      return () => clearTimeout(t);
    }
  }, [toast]);
  const active = loans.filter((x) => x.status !== "Returned"),
    overdue = loans.filter((x) => x.status === "Overdue"),
    copies = books.reduce((a, b) => a + b.copies, 0),
    available = books.reduce((a, b) => a + b.available, 0);
  const bname = (id) => books.find((x) => x.id === id)?.title || "Deleted book",
    mname = (id) => members.find((x) => x.id === id)?.name || "Unknown member";
  const filtered = useMemo(
    () =>
      books.filter(
        (b) =>
          (!query ||
            [b.title, b.author, b.category, b.isbn, b.indexNo].some((x) =>
              x.toLowerCase().includes(query.toLowerCase()),
            )) &&
          (filter === "All" || b.category === filter),
      ),
    [books, query, filter],
  );
  function saveBook(f) {
    if (f.id)
      setBooks((p) =>
        p.map((b) =>
          b.id === f.id
            ? { ...f, copies: +f.copies, available: +f.available }
            : b,
        ),
      );
    else
      setBooks((p) => [
        {
          ...f,
          id: Date.now(),
          indexNo: `LIB-${String(Math.max(0, ...p.map((x) => Number((x.indexNo || "").replace("LIB-", "")) || 0)) + 1).padStart(4, "0")}`,
          copies: +f.copies,
          available: +f.copies,
        },
        ...p,
      ]);
    setModal(null);
    setToast("Book catalog updated.");
  }
  function saveMember(f) {
    if (f.id)
      setMembers((p) => p.map((m) => (m.id === f.id ? { ...m, ...f } : m)));
    else
      setMembers((p) => [
        {
          ...f,
          id: "MB-" + Math.floor(1000 + Math.random() * 8999),
          joined: "Nov 10, 2026",
          borrowed: 0,
        },
        ...p,
      ]);
    setModal(null);
    setToast("Member record saved.");
  }
  function checkout(bookId, memberId) {
    let b = books.find((x) => x.id === +bookId);
    if (!b || !b.available)
      return setToast("This title has no available copies.");
    let now = new Date(),
      due = new Date();
    due.setDate(due.getDate() + 7);
    let fmt = (d) =>
      d.toLocaleDateString("en-US", {
        month: "short",
        day: "2-digit",
        year: "numeric",
      });
    setBooks((p) =>
      p.map((x) => (x.id === b.id ? { ...x, available: x.available - 1 } : x)),
    );
    setMembers((p) =>
      p.map((x) =>
        x.id === memberId ? { ...x, borrowed: x.borrowed + 1 } : x,
      ),
    );
    setLoans((p) => [
      {
        id: "LN-" + Date.now().toString().slice(-4),
        bookId: b.id,
        memberId,
        borrowed: fmt(now),
        due: fmt(due),
        status: "Borrowed",
      },
      ...p,
    ]);
    setModal(null);
    setToast("Checkout completed successfully.");
  }
  function returnBook(l) {
    setLoans((p) =>
      p.map((x) => (x.id === l.id ? { ...x, status: "Returned" } : x)),
    );
    setBooks((p) =>
      p.map((x) =>
        x.id === l.bookId
          ? { ...x, available: Math.min(x.copies, x.available + 1) }
          : x,
      ),
    );
    setMembers((p) =>
      p.map((x) =>
        x.id === l.memberId
          ? { ...x, borrowed: Math.max(0, x.borrowed - 1) }
          : x,
      ),
    );
    setToast("Book returned successfully.");
  }
  const nav = [
    ["Overview", LayoutDashboard],
    ["Book collection", BookOpen],
    ["Indexing", ListOrdered],
    ["Members", Users],
    ["Circulation", ArrowLeftRight],
    ["Insights", ChartNoAxesCombined],
  ];
  return (
    <div className="app">
      <aside className={`sidebar ${mobile ? "show" : ""}`}>
        <div className="logo">
          <div className="logoicon">
            <LibraryBig />
          </div>
          <div>
            <b>Leaf Library</b>
            <small>LIBRARY WORKSPACE</small>
          </div>
          <button className="closemobile" onClick={() => setMobile(false)}>
            <X />
          </button>
        </div>
        <div className="branch">
          <div className="branchseal">LL</div>
          <div>
            <b>NU Learning Commons</b>
            <small>Manila · Main branch</small>
          </div>
          <ChevronDown size={15} />
        </div>
        <div className="navlabel">WORKSPACE</div>
        <nav>
          {nav.map(([name, I]) => (
            <button
              key={name}
              onClick={() => {
                setTab(name);
                setMobile(false);
                setQuery("");
              }}
              className={tab === name ? "active" : ""}
            >
              <I size={18} />
              {name}
              {name === "Circulation" && (
                <span className="navcount">{active.length}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebottom">
          <div className="user">
            <div className="avatar dark">LI</div>
            <div>
              <b>Library Admin</b>
              <small>Administrator</small>
            </div>
            <MoreHorizontal size={18} />
          </div>
        </div>
      </aside>
      {mobile && <div className="scrim" onClick={() => setMobile(false)} />}
      <main className="main">
        <header className="top">
          <div className="top-left">
            <button className="hamb" onClick={() => setMobile(true)}>
              <Menu />
            </button>
            <span>Workspace</span>
            <b>/</b>
            <strong>{tab}</strong>
          </div>
          <div className="top-right">
            <div className="date">
              <CalendarDays size={15} /> Tuesday, November 10, 2026
            </div>
            <button
              className="bell"
              onClick={() =>
                setToast(
                  overdue.length
                    ? `${overdue.length} overdue book(s) need attention.`
                    : "No new notifications.",
                )
              }
            >
              <Bell size={18} />
              <i />
            </button>
            <div className="avatar">LI</div>
          </div>
        </header>
        <div className="page">
          {tab === "Overview" && (
            <>
              <section className="hero">
                <div className="hero-copy">
                  <div className="kicker">
                    <span /> YOUR LIBRARY, IN GOOD ORDER
                  </div>
                  <h1>
                    Make room for
                    <br />
                    <em>new stories.</em>
                  </h1>
                  <p>Welcome back. Here's your library at a glance.</p>
                  <button onClick={() => setTab("Book collection")}>
                    Explore collection <ArrowUpRight size={16} />
                  </button>
                </div>
                <div className="hero-visual">
                  <div className="sun" />
                  <div className="stack s1" />
                  <div className="stack s2" />
                  <div className="stack s3" />
                  <div className="plant">✳</div>
                </div>
                <div className="hero-note">READ · DISCOVER · RETURN</div>
              </section>
              <div className="metric-grid">
                <Metric
                  label="Books in collection"
                  value={copies}
                  icon={BookOpen}
                  note={`${books.length} unique titles`}
                  color="green"
                />
                <Metric
                  label="Available to borrow"
                  value={available}
                  icon={Bookmark}
                  note={`${Math.round((available / (copies || 1)) * 100)}% of total copies`}
                  color="yellow"
                />
                <Metric
                  label="Registered members"
                  value={members.length}
                  icon={Users}
                  note="Active library accounts"
                  color="lavender"
                />
                <Metric
                  label="Currently borrowed"
                  value={active.length}
                  icon={ArrowLeftRight}
                  note={`${overdue.length} overdue item(s)`}
                  color="pink"
                />
              </div>
              <div className="section-head">
                <div>
                  <span className="eyebrow">THE DAILY SHELF</span>
                  <h2>Recently borrowed</h2>
                </div>
                <button
                  className="linkbtn"
                  onClick={() => setTab("Circulation")}
                >
                  See all activity <ArrowUpRight size={15} />
                </button>
              </div>
              <div className="panel">
                <LoanRows
                  loans={loans.slice(0, 4)}
                  bname={bname}
                  mname={mname}
                />
              </div>
              <div className="bottom-grid">
                <div className="panel feature-panel">
                  <div className="section-head inner">
                    <div>
                      <span className="eyebrow">DISCOVER</span>
                      <h2>Staff picks</h2>
                    </div>
                    <button
                      className="linkbtn"
                      onClick={() => setTab("Book collection")}
                    >
                      View catalog <ArrowUpRight size={15} />
                    </button>
                  </div>
                  <div className="pick-grid">
                    {books.slice(0, 3).map((b) => (
                      <BookTile
                        key={b.id}
                        book={b}
                        onClick={() => setModal({ kind: "checkout", book: b })}
                      />
                    ))}
                  </div>
                </div>
                <div className="panel attention">
                  <div className="section-head inner">
                    <div>
                      <span className="eyebrow">FOLLOW UP</span>
                      <h2>Needs attention</h2>
                    </div>
                    <span className="counter">{overdue.length}</span>
                  </div>
                  {overdue.length ? (
                    overdue.map((l) => (
                      <div className="overdue" key={l.id}>
                        <AlertCircle size={17} />
                        <div>
                          <b>{bname(l.bookId)}</b>
                          <small>
                            {mname(l.memberId)} · Due {l.due}
                          </small>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="allgood">
                      <CheckCircle2 />
                      <b>Everything is on track</b>
                      <small>No overdue books right now.</small>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
          {tab === "Book collection" && (
            <>
              <PageTitle
                label="THE CATALOG"
                title="Book collection"
                desc="A little something for every curious mind."
                action={
                  <button
                    className="solid"
                    onClick={() => setModal({ kind: "book" })}
                  >
                    <Plus size={16} /> Add a title
                  </button>
                }
              />
              <div className="catalog-tools">
                <div className="search">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Find a title, author, ISBN..."
                  />
                </div>
                <div className="filter">
                  <Filter size={15} />
                  <select
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                  >
                    <option>All</option>
                    {[...new Set(books.map((b) => b.category))].map((x) => (
                      <option>{x}</option>
                    ))}
                  </select>
                </div>
                <button
                  className={`viewbtn ${view === "grid" ? "chosen" : ""}`}
                  onClick={() => setView("grid")}
                >
                  <Grid2X2 size={16} />
                </button>
                <button
                  className={`viewbtn ${view === "list" ? "chosen" : ""}`}
                  onClick={() => setView("list")}
                >
                  <List size={16} />
                </button>
              </div>
              <div
                className={
                  view === "grid" ? "catalog-grid" : "panel catalog-list"
                }
              >
                {filtered.map((b) =>
                  view === "grid" ? (
                    <BookTile
                      key={b.id}
                      book={b}
                      admin
                      onEdit={() => setModal({ kind: "book", item: b })}
                      onDelete={() => {
                        if (confirm(`Delete ${b.title}?`))
                          setBooks((p) => p.filter((x) => x.id !== b.id));
                      }}
                      onClick={() => setModal({ kind: "checkout", book: b })}
                    />
                  ) : (
                    <div className="listbook" key={b.id}>
                      <div className={`cover ${b.color}`}>
                        <BookOpen />
                      </div>
                      <div className="listdetail">
                        <b>{b.title}</b>
                        <small>
                          {b.author} · {b.category} · {b.isbn}
                        </small>
                      </div>
                      <span>
                        {b.available}/{b.copies} available
                      </span>
                      <button
                        className="iconbutton"
                        onClick={() => setModal({ kind: "book", item: b })}
                      >
                        <Pencil size={15} />
                      </button>
                      <button
                        className="iconbutton"
                        onClick={() =>
                          setBooks((p) => p.filter((x) => x.id !== b.id))
                        }
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  ),
                )}
              </div>
              {!filtered.length && (
                <div className="empty">No books found. Try another search.</div>
              )}
            </>
          )}
          {tab === "Indexing" && (
            <>
              <PageTitle
                label="CATALOG CONTROL"
                title="Book indexing"
                desc="Manage unique accession numbers and locate every title in your collection."
                action={
                  <button
                    className="solid"
                    onClick={() => {
                      let n = books.filter((b) => !b.indexNo).length;
                      setBooks((p) =>
                        p.map((b, i) => ({
                          ...b,
                          indexNo:
                            b.indexNo ||
                            `LIB-${String(i + 1).padStart(4, "0")}`,
                        })),
                      );
                      setToast(
                        n
                          ? `${n} missing index number(s) assigned.`
                          : "All books already have index numbers.",
                      );
                    }}
                  >
                    <ListOrdered size={16} /> Auto-index missing
                  </button>
                }
              />
              <div className="index-summary">
                <div className="index-card">
                  <span className="eyebrow">TOTAL INDEXED TITLES</span>
                  <strong>{books.length}</strong>
                  <small>Unique catalog records</small>
                </div>
                <div className="index-card">
                  <span className="eyebrow">INDEX FORMAT</span>
                  <strong className="index-format">LIB-0001</strong>
                  <small>Prefix + four-digit number</small>
                </div>
                <div className="index-card">
                  <span className="eyebrow">UNIQUE INDEXES</span>
                  <strong>{new Set(books.map((b) => b.indexNo)).size}</strong>
                  <small>Distinct accession codes</small>
                </div>
              </div>
              <div className="catalog-tools">
                <div className="search">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search index number, title, author, ISBN..."
                  />
                </div>
                <span className="counttext">
                  Showing{" "}
                  {
                    books.filter(
                      (b) =>
                        !query ||
                        [b.indexNo, b.title, b.author, b.isbn].some((x) =>
                          (x || "").toLowerCase().includes(query.toLowerCase()),
                        ),
                    ).length
                  }{" "}
                  records
                </span>
              </div>
              <div className="panel">
                <div className="paneltop">
                  <h3>Accession register</h3>
                  <span>Unique book identification</span>
                </div>
                <div className="loanwrap">
                  <table>
                    <thead>
                      <tr>
                        <th>INDEX NUMBER</th>
                        <th>BOOK TITLE</th>
                        <th>AUTHOR</th>
                        <th>ISBN</th>
                        <th>SHELF LOCATION</th>
                        <th>AVAILABILITY</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
                      {books
                        .filter(
                          (b) =>
                            !query ||
                            [
                              b.indexNo,
                              b.title,
                              b.author,
                              b.isbn,
                              b.shelf,
                            ].some((x) =>
                              (x || "")
                                .toLowerCase()
                                .includes(query.toLowerCase()),
                            ),
                        )
                        .sort((a, b) =>
                          (a.indexNo || "").localeCompare(b.indexNo || ""),
                        )
                        .map((b) => (
                          <tr key={b.id}>
                            <td>
                              <span className="indexcode">
                                {b.indexNo || "UNASSIGNED"}
                              </span>
                            </td>
                            <td>
                              <b className="tabletitle">{b.title}</b>
                            </td>
                            <td>{b.author}</td>
                            <td>{b.isbn || "—"}</td>
                            <td>{b.shelf || "—"}</td>
                            <td>
                              <span
                                className={`tag ${b.available ? "green" : "red"}`}
                              >
                                {b.available} / {b.copies} copies
                              </span>
                            </td>
                            <td>
                              <button
                                className="iconbutton"
                                title="Edit index details"
                                onClick={() =>
                                  setModal({ kind: "book", item: b })
                                }
                              >
                                <Pencil size={15} />
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                  {!books.length && (
                    <div className="empty">No catalog records yet.</div>
                  )}
                </div>
              </div>
              <p className="index-help">
                <ListOrdered size={15} /> Each book receives a unique accession
                number. Use this index number to identify and locate a title
                quickly.
              </p>
            </>
          )}
          {tab === "Members" && (
            <>
              <PageTitle
                label="COMMUNITY"
                title="Library members"
                desc="The readers who make this place feel alive."
                action={
                  <button
                    className="solid"
                    onClick={() => setModal({ kind: "member" })}
                  >
                    <UserPlus size={16} /> Register member
                  </button>
                }
              />
              <div className="catalog-tools">
                <div className="search">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search name, email, member ID..."
                  />
                </div>
                <span className="counttext">{members.length} members</span>
              </div>
              <div className="panel">
                <table>
                  <thead>
                    <tr>
                      <th>MEMBER</th>
                      <th>MEMBER ID</th>
                      <th>JOINED</th>
                      <th>ON LOAN</th>
                      <th>STATUS</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {members
                      .filter((m) =>
                        `${m.name} ${m.email} ${m.id}`
                          .toLowerCase()
                          .includes(query.toLowerCase()),
                      )
                      .map((m) => (
                        <tr key={m.id}>
                          <td>
                            <div className="membercell">
                              <div className="avatar">{initials(m.name)}</div>
                              <div>
                                <b>{m.name}</b>
                                <small>{m.email}</small>
                              </div>
                            </div>
                          </td>
                          <td>{m.id}</td>
                          <td>{m.joined}</td>
                          <td>{m.borrowed} books</td>
                          <td>
                            <span className="tag green">● Active</span>
                          </td>
                          <td>
                            <button
                              className="iconbutton"
                              onClick={() =>
                                setModal({ kind: "member", item: m })
                              }
                            >
                              <Pencil size={15} />
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
          {tab === "Circulation" && (
            <>
              <PageTitle
                label="LOAN DESK"
                title="Borrow & return"
                desc="Keep every book moving from one reader to the next."
                action={
                  <button
                    className="solid"
                    onClick={() => setModal({ kind: "checkout" })}
                  >
                    <Plus size={16} /> New checkout
                  </button>
                }
              />
              <div className="metric-grid three">
                <Metric
                  label="Active loans"
                  value={active.length}
                  icon={ArrowLeftRight}
                  color="green"
                />
                <Metric
                  label="Overdue"
                  value={overdue.length}
                  icon={Clock3}
                  color="pink"
                />
                <Metric
                  label="Returned"
                  value={loans.filter((l) => l.status === "Returned").length}
                  icon={CheckCircle2}
                  color="yellow"
                />
              </div>
              <div className="panel">
                <div className="paneltop">
                  <h3>All transactions</h3>
                  <span>{loans.length} records</span>
                </div>
                <LoanRows
                  loans={loans}
                  bname={bname}
                  mname={mname}
                  onReturn={returnBook}
                />
              </div>
            </>
          )}
          {tab === "Insights" && (
            <>
              <PageTitle
                label="LIBRARY PULSE"
                title="Collection insights"
                desc="A closer look at what readers are borrowing."
              />
              <div className="metric-grid">
                <Metric
                  label="Unique titles"
                  value={books.length}
                  icon={BookOpen}
                  color="green"
                />
                <Metric
                  label="Total copies"
                  value={copies}
                  icon={LibraryBig}
                  color="yellow"
                />
                <Metric
                  label="Members"
                  value={members.length}
                  icon={Users}
                  color="lavender"
                />
                <Metric
                  label="Active loans"
                  value={active.length}
                  icon={ArrowLeftRight}
                  color="pink"
                />
              </div>
              <div className="insightgrid">
                <div className="panel insightpanel">
                  <span className="eyebrow">COLLECTION MIX</span>
                  <h2>Books by category</h2>
                  {[...new Set(books.map((b) => b.category))].map((cat) => (
                    <div className="baritem" key={cat}>
                      <div>
                        <span>{cat}</span>
                        <b>{books.filter((b) => b.category === cat).length}</b>
                      </div>
                      <div className="bar">
                        <i
                          style={{
                            width: `${(books.filter((b) => b.category === cat).length / (books.length || 1)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="panel insightpanel">
                  <span className="eyebrow">AVAILABILITY</span>
                  <h2>Copy status</h2>
                  <div className="bigpercent">
                    {Math.round((available / (copies || 1)) * 100)}
                    <small>%</small>
                  </div>
                  <p className="muted">
                    of all book copies are available to borrow.
                  </p>
                  <div className="bar">
                    <i
                      style={{ width: `${(available / (copies || 1)) * 100}%` }}
                    />
                  </div>
                  <div className="statuslegend">
                    <span>● Available: {available}</span>
                    <span>● Borrowed: {copies - available}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        <footer>
          <span>
            LEAF LIBRARY <i>·</i> LIBRARY WORKSPACE
          </span>
          <span>Made for curious minds.</span>
        </footer>
      </main>
      {modal && (
        <Modal
          modal={modal}
          books={books}
          members={members}
          close={() => setModal(null)}
          saveBook={saveBook}
          saveMember={saveMember}
          checkout={checkout}
        />
      )}
      {toast && (
        <div className="toast">
          <CheckCircle2 size={17} />
          {toast}
        </div>
      )}
    </div>
  );
}
function Metric({ label, value, icon: I, note, color }) {
  return (
    <div className="metric">
      <div className={`metricicon ${color}`}>
        <I size={19} />
      </div>
      <div className="metricbody">
        <small>{label}</small>
        <strong>{value}</strong>
        {note && <span>{note}</span>}
      </div>
    </div>
  );
}
function PageTitle({ label, title, desc, action }) {
  return (
    <div className="pagetitle">
      <div>
        <span className="eyebrow">{label}</span>
        <h1>{title}</h1>
        <p>{desc}</p>
      </div>
      {action}
    </div>
  );
}
function BookTile({ book, admin, onEdit, onDelete, onClick }) {
  return (
    <article className="booktile">
      <div className={`cover ${book.color}`} onClick={onClick}>
        <div className="coverbrand">LEAF LIBRARY</div>
        <BookOpen size={27} />
        <b>{book.title}</b>
        <small>{book.author}</small>
      </div>
      <div className="tileinfo">
        <div>
          <span className="genre">{book.category}</span>
          <b>{book.title}</b>
          <small>{book.author}</small>
        </div>
        <div className="tilebottom">
          <span className={book.available ? "available" : "unavailable"}>
            {book.available
              ? `${book.available} available`
              : "Currently borrowed"}
          </span>
          <button onClick={onClick}>
            {book.available ? "Borrow" : "Details"} <ArrowUpRight size={13} />
          </button>
        </div>
        {admin && (
          <div className="tileadmin">
            <button onClick={onEdit}>
              <Pencil size={14} /> Edit
            </button>
            <button onClick={onDelete}>
              <Trash2 size={14} /> Delete
            </button>
          </div>
        )}
      </div>
    </article>
  );
}
function LoanRows({ loans, bname, mname, onReturn }) {
  return (
    <div className="loanwrap">
      <table>
        <thead>
          <tr>
            <th>BOOK</th>
            <th>READER</th>
            <th>DATE BORROWED</th>
            <th>DUE DATE</th>
            <th>STATUS</th>
            {onReturn && <th>ACTION</th>}
          </tr>
        </thead>
        <tbody>
          {loans.map((l) => (
            <tr key={l.id}>
              <td>
                <div className="loanbook">
                  <div className="tinycover">
                    <BookOpen size={14} />
                  </div>
                  <div>
                    <b>{bname(l.bookId)}</b>
                    <small>{l.id}</small>
                  </div>
                </div>
              </td>
              <td>{mname(l.memberId)}</td>
              <td>{l.borrowed}</td>
              <td>{l.due}</td>
              <td>
                <span
                  className={`tag ${l.status === "Overdue" ? "red" : l.status === "Returned" ? "green" : "yellow"}`}
                >
                  ● {l.status}
                </span>
              </td>
              {onReturn && (
                <td>
                  {l.status !== "Returned" && (
                    <button className="return" onClick={() => onReturn(l)}>
                      <RotateCcw size={13} /> Return
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      {!loans.length && <div className="empty">No transactions yet.</div>}
    </div>
  );
}
function Modal({
  modal,
  books,
  members,
  close,
  saveBook,
  saveMember,
  checkout,
}) {
  let item = modal.item;
  const [form, setForm] = useState(
    item
      ? { ...item }
      : {
          title: "",
          author: "",
          category: "Fiction",
          isbn: "",
          copies: 1,
          available: 1,
          shelf: "",
          name: "",
          email: "",
        },
  );
  const [book, setBook] = useState(
    modal.book?.id || books.find((b) => b.available)?.id || "",
  );
  const [member, setMember] = useState(members[0]?.id || "");
  const change = (e) =>
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  let kind = modal.kind;
  function submit(e) {
    e.preventDefault();
    if (kind === "book")
      saveBook({
        ...form,
        id: item?.id,
        available: item ? +form.available : +form.copies,
      });
    if (kind === "member") saveMember({ ...form, id: item?.id });
    if (kind === "checkout") checkout(book, member);
  }
  return (
    <div
      className="modalbg"
      onMouseDown={(e) => e.target === e.currentTarget && close()}
    >
      <form className="modal" onSubmit={submit}>
        <div className="modalhead">
          <div>
            <span className="eyebrow">LEAF LIBRARY</span>
            <h2>
              {kind === "book"
                ? item
                  ? "Edit book details"
                  : "Add to collection"
                : kind === "member"
                  ? item
                    ? "Edit member"
                    : "Register a reader"
                  : "Book checkout"}
            </h2>
          </div>
          <button type="button" className="iconbutton" onClick={close}>
            <X />
          </button>
        </div>
        {kind === "book" && (
          <div className="fields">
            <label className="full">
              Book title
              <input
                required
                name="title"
                value={form.title}
                onChange={change}
                placeholder="Enter title"
              />
            </label>
            <label>
              Author
              <input
                required
                name="author"
                value={form.author}
                onChange={change}
                placeholder="Author name"
              />
            </label>
            <label>
              Category
              <select name="category" value={form.category} onChange={change}>
                {[
                  "Fiction",
                  "Non-fiction",
                  "Technology",
                  "Design",
                  "Art",
                  "Self-help",
                  "Biography",
                  "Science",
                  "History",
                ].map((x) => (
                  <option>{x}</option>
                ))}
              </select>
            </label>
            <label>
              Index number
              <input
                name="indexNo"
                value={form.indexNo || ""}
                onChange={change}
                placeholder="Auto-assigned for new books"
              />
            </label>
            <label>
              ISBN
              <input
                name="isbn"
                value={form.isbn}
                onChange={change}
                placeholder="ISBN"
              />
            </label>
            <label>
              Shelf
              <input
                name="shelf"
                value={form.shelf}
                onChange={change}
                placeholder="e.g. A-01"
              />
            </label>
            <label>
              Copies
              <input
                type="number"
                min="1"
                name="copies"
                value={form.copies}
                onChange={change}
              />
            </label>
            {item && (
              <label>
                Available
                <input
                  type="number"
                  min="0"
                  max={form.copies}
                  name="available"
                  value={form.available}
                  onChange={change}
                />
              </label>
            )}
          </div>
        )}
        {kind === "member" && (
          <div className="fields">
            <label className="full">
              Full name
              <input
                required
                name="name"
                value={form.name}
                onChange={change}
                placeholder="Reader's full name"
              />
            </label>
            <label className="full">
              Email address
              <input
                required
                type="email"
                name="email"
                value={form.email}
                onChange={change}
                placeholder="reader@email.com"
              />
            </label>
          </div>
        )}
        {kind === "checkout" && (
          <div className="fields">
            <label className="full">
              Choose a book
              <select value={book} onChange={(e) => setBook(e.target.value)}>
                {books
                  .filter((b) => b.available > 0)
                  .map((b) => (
                    <option value={b.id}>
                      {b.title} — {b.available} available
                    </option>
                  ))}
              </select>
            </label>
            <label className="full">
              Choose a member
              <select
                value={member}
                onChange={(e) => setMember(e.target.value)}
              >
                {members.map((m) => (
                  <option value={m.id}>
                    {m.name} ({m.id})
                  </option>
                ))}
              </select>
            </label>
            <p className="note full">
              <Clock3 size={16} /> Standard borrowing period: 7 days. Due date
              is calculated automatically.
            </p>
          </div>
        )}
        <div className="modalactions">
          <button type="button" className="cancel" onClick={close}>
            Cancel
          </button>
          <button className="solid" type="submit">
            {kind === "book"
              ? item
                ? "Save changes"
                : "Add book"
              : kind === "member"
                ? item
                  ? "Save changes"
                  : "Register member"
                : "Confirm checkout"}
          </button>
        </div>
      </form>
    </div>
  );
}
export default App;
