import {
  ArrowLeftRight,
  BookOpen,
  ChartNoAxesCombined,
  LayoutDashboard,
  LibraryBig,
  ListOrdered,
  LogOut,
  Users,
  X,
} from "lucide-react";

const navigation = [
  ["Overview", LayoutDashboard],
  ["Book collection", BookOpen],
  ["Indexing", ListOrdered],
  ["Members", Users],
  ["Circulation", ArrowLeftRight],
  ["Insights", ChartNoAxesCombined],
];

function Sidebar({ activePage, setActivePage, mobile, setMobile, activeCount, user, onSignOut }) {
  return (
    <aside className={`sidebar ${mobile ? "show" : ""}`}>
      <div className="logo">
        <div className="logoicon"><LibraryBig /></div>
        <div>
          <b>Leaf Library</b>
          <small>LIBRARY WORKSPACE</small>
        </div>
        <button className="closemobile" aria-label="Close menu" onClick={() => setMobile(false)}>
          <X />
        </button>
      </div>

      <div className="branch">
        <div className="branchseal">LL</div>
        <div>
          <b>NU Learning Commons</b>
          <small>Manila · Main branch</small>
        </div>
      </div>

      <div className="navlabel">WORKSPACE</div>
      <nav aria-label="Main navigation">
        {navigation.map(([name, Icon]) => (
          <button
            key={name}
            aria-current={activePage === name ? "page" : undefined}
            onClick={() => {
              setActivePage(name);
              setMobile(false);
            }}
            className={activePage === name ? "active" : ""}
          >
            <Icon size={18} />
            {name}
            {name === "Circulation" && <span className="navcount">{activeCount}</span>}
          </button>
        ))}
      </nav>

      <div className="sidebottom">
        <div className="user">
          <div className="avatar dark">{user?.name?.split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase()}</div>
          <div>
            <b>{user?.name || "Library member"}</b>
            <small>{user?.role || user?.email}</small>
          </div>
          <button className="signout-button" type="button" onClick={onSignOut} aria-label="Sign out" title="Sign out"><LogOut size={17} /></button>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;
