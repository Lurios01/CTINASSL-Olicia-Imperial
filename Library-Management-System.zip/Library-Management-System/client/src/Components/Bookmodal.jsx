﻿import { useState } from "react";
import { Clock3, X } from "lucide-react";

function BookModal({
  modal,
  books,
  members,
  close,
  saveBook,
  saveMember,
  checkout,
}) {
  let item = modal.item;
  const [form, setForm] = useState(
    item
      ? { ...item }
      : {
          title: "",
          author: "",
          category: "Fiction",
          isbn: "",
          copies: 1,
          available: 1,
          shelf: "",
          name: "",
          email: "",
        },
  );
  const [book, setBook] = useState(
    modal.book?.id || books.find((b) => b.available)?.id || "",
  );
  const [member, setMember] = useState(members[0]?.id || "");
  const change = (e) =>
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  let kind = modal.kind;
  function submit(e) {
    e.preventDefault();
    if (kind === "book")
      saveBook({
        ...form,
        id: item?.id,
        available: item ? +form.available : +form.copies,
      });
    if (kind === "member") saveMember({ ...form, recordId: item?.id });
    if (kind === "checkout") checkout(book, member);
  }
  return (
    <div
      className="modalbg"
      onMouseDown={(e) => e.target === e.currentTarget && close()}
    >
      <form className="modal" onSubmit={submit}>
        <div className="modalhead">
          <div>
            <span className="eyebrow">LEAF LIBRARY</span>
            <h2>
              {kind === "book"
                ? item
                  ? "Edit book details"
                  : "Add to collection"
                : kind === "member"
                  ? item
                    ? "Edit member"
                    : "Register a reader"
                  : "Book checkout"}
            </h2>
          </div>
          <button type="button" className="iconbutton" onClick={close}>
            <X />
          </button>
        </div>
        {kind === "book" && (
          <div className="fields">
            <label className="full">
              Book title
              <input
                required
                name="title"
                value={form.title}
                onChange={change}
                placeholder="Enter title"
              />
            </label>
            <label>
              Author
              <input
                required
                name="author"
                value={form.author}
                onChange={change}
                placeholder="Author name"
              />
            </label>
            <label>
              Category
              <select name="category" value={form.category} onChange={change}>
                {[
                  "Fiction",
                  "Non-fiction",
                  "Technology",
                  "Design",
                  "Art",
                  "Self-help",
                  "Biography",
                  "Science",
                  "History",
                ].map((x) => (
                  <option>{x}</option>
                ))}
              </select>
            </label>
            <label>
              Index number
              <input
                name="indexNo"
                value={form.indexNo || ""}
                onChange={change}
                placeholder="Auto-assigned for new books"
              />
            </label>
            <label>
              ISBN
              <input
                name="isbn"
                value={form.isbn}
                onChange={change}
                placeholder="ISBN"
              />
            </label>
            <label>
              Shelf
              <input
                name="shelf"
                value={form.shelf}
                onChange={change}
                placeholder="e.g. A-01"
              />
            </label>
            <label>
              Copies
              <input
                type="number"
                min="1"
                name="copies"
                value={form.copies}
                onChange={change}
              />
            </label>
            {item && (
              <label>
                Available
                <input
                  type="number"
                  min="0"
                  max={form.copies}
                  name="available"
                  value={form.available}
                  onChange={change}
                />
              </label>
            )}
          </div>
        )}
        {kind === "member" && (
          <div className="fields">
            <label className="full">
              Member ID
              <input
                name="id"
                value={form.id || ""}
                onChange={change}
                placeholder="Leave blank to assign automatically"
              />
            </label>
            <label className="full">
              Full name
              <input
                required
                name="name"
                value={form.name}
                onChange={change}
                placeholder="Reader's full name"
              />
            </label>
            <label className="full">
              Email address
              <input
                required
                type="email"
                name="email"
                value={form.email}
                onChange={change}
                placeholder="reader@email.com"
              />
            </label>
          </div>
        )}
        {kind === "checkout" && (
          <div className="fields">
            <label className="full">
              Choose a book
              <select value={book} onChange={(e) => setBook(e.target.value)}>
                {books
                  .filter((b) => b.available > 0)
                  .map((b) => (
                    <option value={b.id}>
                      {b.title} â€” {b.available} available
                    </option>
                  ))}
              </select>
            </label>
            <label className="full">
              Choose a member
              <select
                value={member}
                onChange={(e) => setMember(e.target.value)}
              >
                {members.map((m) => (
                  <option value={m.id}>
                    {m.name} ({m.id})
                  </option>
                ))}
              </select>
            </label>
            <p className="note full">
              <Clock3 size={16} /> Standard borrowing period: 7 days. Due date
              is calculated automatically.
            </p>
          </div>
        )}
        <div className="modalactions">
          <button type="button" className="cancel" onClick={close}>
            Cancel
          </button>
          <button className="solid" type="submit">
            {kind === "book"
              ? item
                ? "Save changes"
                : "Add book"
              : kind === "member"
                ? item
                  ? "Save changes"
                  : "Register member"
                : "Confirm checkout"}
          </button>
        </div>
      </form>
    </div>
  );
}
export default BookModal;

