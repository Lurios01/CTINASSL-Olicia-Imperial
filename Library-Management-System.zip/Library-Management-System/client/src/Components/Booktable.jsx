
import {
  BookOpen,
  Pencil,
  Trash2
} from "lucide-react";

function BookTable({ books, onEdit, onDelete }) {
  return (
    <div className="table-container">

      <table>
        <thead>
          <tr>
            <th>BOOK DETAILS</th>
            <th>ISBN</th>
            <th>CATEGORY</th>
            <th>QUANTITY</th>
            <th>AVAILABLE</th>
            <th>STATUS</th>
            <th>ACTIONS</th>
          </tr>
        </thead>

        <tbody>
          {books.map((book) => (
            <tr key={book.id}>

              <td>
                <div className="book-title">
                  <div className="book-icon">
                    <BookOpen size={19} />
                  </div>

                  <div>
                    <strong>{book.title}</strong>
                    <span>{book.author}</span>
                  </div>
                </div>
              </td>

              <td>{book.isbn}</td>

              <td>
                <span className="category-tag">
                  {book.category}
                </span>
              </td>

              <td>{book.quantity}</td>

              <td>{book.available}</td>

              <td>
                <span className={
                  book.available > 0
                    ? "status available"
                    : "status unavailable"
                }>
                  {book.available > 0
                    ? "Available"
                    : "Out of Stock"}
                </span>
              </td>

              <td>
                <div className="action-buttons">

                  <button
                    className="edit-action"
                    onClick={() => onEdit(book)}
                  >
                    <Pencil size={16} />
                  </button>

                  <button
                    className="delete-action"
                    onClick={() => onDelete(book.id)}
                  >
                    <Trash2 size={16} />
                  </button>

                </div>
              </td>

            </tr>
          ))}
        </tbody>
      </table>

      {books.length === 0 && (
        <p className="empty-state">
          No books found.
        </p>
      )}

    </div>
  );
}

export default BookTable;
