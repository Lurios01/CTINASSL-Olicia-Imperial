function StatCard({ label, title, value, note, description, icon: Icon, color }) {
  return (
    <div className="metric">
      <div className={`metricicon ${color}`}>
        <Icon size={19} />
      </div>
      <div className="metricbody">
        <small>{label || title}</small>
        <strong>{value}</strong>
        {(note || description) && <span>{note || description}</span>}
      </div>
    </div>
  );
}

export default StatCard;
