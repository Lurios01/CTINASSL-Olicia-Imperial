import { Bell, CalendarDays, Menu } from "lucide-react";

function Header({ title, mobile, setMobile, onNotify }) {
  const today = new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(new Date());

  return (
    <header className="top">
      <div className="top-left">
        <button
          className="hamb"
          aria-label="Open navigation menu"
          aria-expanded={mobile}
          onClick={() => setMobile(true)}
        >
          <Menu />
        </button>
        <span>Workspace</span>
        <b>/</b>
        <strong>{title}</strong>
      </div>
      <div className="top-right">
        <div className="date"><CalendarDays size={15} /> {today}</div>
        <button className="bell" aria-label="Show notifications" onClick={onNotify}>
          <Bell size={18} />
          <i />
        </button>
        <div className="avatar">LI</div>
      </div>
    </header>
  );
}

export default Header;
