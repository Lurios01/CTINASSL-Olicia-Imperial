﻿import React, { useEffect, useMemo, useState } from "react";
import BookModal from "./Components/Bookmodal";
import {
  BookOpen,
  Users,
  ArrowLeftRight,
  ListOrdered,
  Search,
  Plus,
  Bookmark,
  Clock3,
  CheckCircle2,
  AlertCircle,
  Filter,
  Trash2,
  Pencil,
  RotateCcw,
  ArrowUpRight,
  UserPlus,
  LibraryBig,
  Grid2X2,
  List,
} from "lucide-react";
import Sidebar from "./Components/Sidebar";
import Header from "./Components/Header";
import StatCard from "./Components/Statcard";
import AuthPage from "./Auth/AuthPage";
import { getSession, signOut } from "./Auth/authStorage";
const seedBooks = [
  {
    id: 1,
    indexNo: "LIB-0001",
    title: "The Design of Everyday Things",
    author: "Don Norman",
    category: "Design",
    isbn: "9780465050659",
    copies: 8,
    available: 5,
    shelf: "A-12",
    color: "sage",
    year: 2013,
  },
  {
    id: 2,
    indexNo: "LIB-0002",
    title: "Norwegian Wood",
    author: "Haruki Murakami",
    category: "Fiction",
    isbn: "9780375704024",
    copies: 6,
    available: 2,
    shelf: "F-08",
    color: "rose",
    year: 1987,
  },
  {
    id: 3,
    indexNo: "LIB-0003",
    title: "The Pragmatic Programmer",
    author: "David Thomas",
    category: "Technology",
    isbn: "9780135957059",
    copies: 5,
    available: 0,
    shelf: "T-03",
    color: "blue",
    year: 2019,
  },
  {
    id: 4,
    indexNo: "LIB-0004",
    title: "Before the Coffee Gets Cold",
    author: "Toshikazu Kawaguchi",
    category: "Fiction",
    isbn: "9781335430991",
    copies: 7,
    available: 4,
    shelf: "F-11",
    color: "gold",
    year: 2015,
  },
  {
    id: 5,
    indexNo: "LIB-0005",
    title: "Steal Like an Artist",
    author: "Austin Kleon",
    category: "Art",
    isbn: "9780761169253",
    copies: 4,
    available: 3,
    shelf: "A-06",
    color: "lavender",
    year: 2012,
  },
  {
    id: 6,
    indexNo: "LIB-0006",
    title: "Atomic Habits",
    author: "James Clear",
    category: "Self-help",
    isbn: "9780735211292",
    copies: 9,
    available: 7,
    shelf: "S-02",
    color: "peach",
    year: 2018,
  },
  {
    id: 7,
    indexNo: "LIB-0007",
    title: "Educated",
    author: "Tara Westover",
    category: "Biography",
    isbn: "9780399590504",
    copies: 3,
    available: 1,
    shelf: "B-02",
    color: "blue",
    year: 2018,
  },
  {
    id: 8,
    indexNo: "LIB-0008",
    title: "The Creative Act",
    author: "Rick Rubin",
    category: "Art",
    isbn: "9780593652886",
    copies: 4,
    available: 4,
    shelf: "A-09",
    color: "sage",
    year: 2023,
  },
];
const seedMembers = [
  {
    id: "MB-1042",
    name: "Mikaela Santos",
    email: "mikaela.s@email.com",
    joined: "Oct 12, 2026",
    borrowed: 2,
  },
  {
    id: "MB-1043",
    name: "Daniel Reyes",
    email: "daniel.r@email.com",
    joined: "Oct 18, 2026",
    borrowed: 1,
  },
  {
    id: "MB-1044",
    name: "Andrea Cruz",
    email: "andrea.c@email.com",
    joined: "Oct 21, 2026",
    borrowed: 0,
  },
  {
    id: "MB-1045",
    name: "Gabriel Lim",
    email: "gabriel.l@email.com",
    joined: "Nov 02, 2026",
    borrowed: 1,
  },
];
const seedLoans = [
  {
    id: "LN-2081",
    bookId: 2,
    memberId: "MB-1042",
    borrowed: "Nov 08, 2026",
    due: "Nov 15, 2026",
    status: "Borrowed",
  },
  {
    id: "LN-2080",
    bookId: 3,
    memberId: "MB-1043",
    borrowed: "Oct 29, 2026",
    due: "Nov 05, 2026",
    status: "Overdue",
  },
  {
    id: "LN-2079",
    bookId: 4,
    memberId: "MB-1045",
    borrowed: "Nov 06, 2026",
    due: "Nov 13, 2026",
    status: "Borrowed",
  },
  {
    id: "LN-2078",
    bookId: 1,
    memberId: "MB-1042",
    borrowed: "Oct 22, 2026",
    due: "Oct 29, 2026",
    status: "Returned",
  },
];
const get = (k, v) => {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? v;
  } catch {
    return v;
  }
};
const initials = (n) =>
  n
    .split(" ")
    .map((x) => x[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
function App() {
  const [session, setSession] = useState(() => getSession());
  const [books, setBooks] = useState(() =>
      get("leaf-books", seedBooks).map((b, i) => ({
        ...b,
        indexNo: b.indexNo || `LIB-${String(i + 1).padStart(4, "0")}`,
      })),
    ),
    [members, setMembers] = useState(() => get("leaf-members", seedMembers)),
    [loans, setLoans] = useState(() => get("leaf-loans", seedLoans));
  const [tab, setTab] = useState("Overview"),
    [query, setQuery] = useState(""),
    [filter, setFilter] = useState("All"),
    [modal, setModal] = useState(null),
    [toast, setToast] = useState(""),
    [mobile, setMobile] = useState(false),
    [view, setView] = useState("grid");
  useEffect(
    () => localStorage.setItem("leaf-books", JSON.stringify(books)),
    [books],
  );
  useEffect(
    () => localStorage.setItem("leaf-members", JSON.stringify(members)),
    [members],
  );
  useEffect(
    () => localStorage.setItem("leaf-loans", JSON.stringify(loans)),
    [loans],
  );
  if (!session) return <AuthPage onAuthenticated={setSession} />;
  useEffect(() => {
    if (toast) {
      let t = setTimeout(() => setToast(""), 2500);
      return () => clearTimeout(t);
    }
  }, [toast]);
  const active = loans.filter((x) => x.status !== "Returned"),
    overdue = loans.filter((x) => x.status === "Overdue"),
    copies = books.reduce((a, b) => a + b.copies, 0),
    available = books.reduce((a, b) => a + b.available, 0);
  const bname = (id) => books.find((x) => x.id === id)?.title || "Deleted book",
    mname = (id) => members.find((x) => x.id === id)?.name || "Unknown member";
  const filtered = useMemo(
    () =>
      books.filter(
        (b) =>
          (!query ||
            [b.title, b.author, b.category, b.isbn, b.indexNo].some((x) =>
              x.toLowerCase().includes(query.toLowerCase()),
            )) &&
          (filter === "All" || b.category === filter),
      ),
    [books, query, filter],
  );
  function saveBook(f) {
    if (f.id)
      setBooks((p) =>
        p.map((b) =>
          b.id === f.id
            ? { ...f, copies: +f.copies, available: +f.available }
            : b,
        ),
      );
    else
      setBooks((p) => [
        {
          ...f,
          id: Date.now(),
          indexNo: `LIB-${String(Math.max(0, ...p.map((x) => Number((x.indexNo || "").replace("LIB-", "")) || 0)) + 1).padStart(4, "0")}`,
          copies: +f.copies,
          available: +f.copies,
        },
        ...p,
      ]);
    setModal(null);
    setToast("Book catalog updated.");
  }
  function saveMember(f) {
    if (session.role !== "Administrator") {
      setToast("Only administrators can register or edit members.");
      setModal(null);
      return;
    }
    const memberId = f.id?.trim() || (f.recordId ? f.recordId : `MB-${Math.floor(1000 + Math.random() * 8999)}`);
    if (members.some((member) => member.id === memberId && member.id !== f.recordId)) {
      setToast("That member ID is already in use.");
      return;
    }
    if (f.recordId) {
      setMembers((previous) => previous.map((member) =>
        member.id === f.recordId ? { ...member, ...f, id: memberId } : member,
      ));
      if (memberId !== f.recordId) {
        setLoans((previous) => previous.map((loan) =>
          loan.memberId === f.recordId ? { ...loan, memberId } : loan,
        ));
      }
    } else {
      setMembers((previous) => [
        { ...f, id: memberId, joined: "Nov 10, 2026", borrowed: 0 },
        ...previous,
      ]);
    }
    setModal(null);
    setToast("Member record saved.");
  }
  function checkout(bookId, memberId) {
    let b = books.find((x) => x.id === +bookId);
    if (!b || !b.available)
      return setToast("This title has no available copies.");
    let now = new Date(),
      due = new Date();
    due.setDate(due.getDate() + 7);
    let fmt = (d) =>
      d.toLocaleDateString("en-US", {
        month: "short",
        day: "2-digit",
        year: "numeric",
      });
    setBooks((p) =>
      p.map((x) => (x.id === b.id ? { ...x, available: x.available - 1 } : x)),
    );
    setMembers((p) =>
      p.map((x) =>
        x.id === memberId ? { ...x, borrowed: x.borrowed + 1 } : x,
      ),
    );
    setLoans((p) => [
      {
        id: "LN-" + Date.now().toString().slice(-4),
        bookId: b.id,
        memberId,
        borrowed: fmt(now),
        due: fmt(due),
        status: "Borrowed",
      },
      ...p,
    ]);
    setModal(null);
    setToast("Checkout completed successfully.");
  }
  function returnBook(l) {
    setLoans((p) =>
      p.map((x) => (x.id === l.id ? { ...x, status: "Returned" } : x)),
    );
    setBooks((p) =>
      p.map((x) =>
        x.id === l.bookId
          ? { ...x, available: Math.min(x.copies, x.available + 1) }
          : x,
      ),
    );
    setMembers((p) =>
      p.map((x) =>
        x.id === l.memberId
          ? { ...x, borrowed: Math.max(0, x.borrowed - 1) }
          : x,
      ),
    );
    setToast("Book returned successfully.");
  }
  return (
    <div className="app">
      <Sidebar
        activePage={tab}
        setActivePage={(page) => {
          setTab(page);
          setQuery("");
        }}
        mobile={mobile}
        setMobile={setMobile}
        activeCount={active.length}
        user={session}
        onSignOut={() => {
          signOut();
          setSession(null);
        }}
      />
      {mobile && <div className="scrim" onClick={() => setMobile(false)} />}
      <main className="main">
        <Header
          title={tab}
          mobile={mobile}
          setMobile={setMobile}
          onNotify={() =>
            setToast(
              overdue.length
                ? `${overdue.length} overdue book(s) need attention.`
                : "No new notifications.",
            )
          }
        />
        <div className="page">
          {tab === "Overview" && (
            <>
              <section className="hero">
                <div className="hero-copy">
                  <div className="kicker">
                    <span /> YOUR LIBRARY, IN GOOD ORDER
                  </div>
                  <h1>
                    Make room for
                    <br />
                    <em>new stories.</em>
                  </h1>
                  <p>Welcome back. Here's your library at a glance.</p>
                  <button onClick={() => setTab("Book collection")}>
                    Explore collection <ArrowUpRight size={16} />
                  </button>
                </div>
                <div className="hero-visual">
                  <div className="sun" />
                  <div className="stack s1" />
                  <div className="stack s2" />
                  <div className="stack s3" />
                  <div className="plant">âœ³</div>
                </div>
                <div className="hero-note">READ Â· DISCOVER Â· RETURN</div>
              </section>
              <div className="metric-grid">
                <StatCard
                  label="Books in collection"
                  value={copies}
                  icon={BookOpen}
                  note={`${books.length} unique titles`}
                  color="green"
                />
                <StatCard
                  label="Available to borrow"
                  value={available}
                  icon={Bookmark}
                  note={`${Math.round((available / (copies || 1)) * 100)}% of total copies`}
                  color="yellow"
                />
                <StatCard
                  label="Registered members"
                  value={members.length}
                  icon={Users}
                  note="Active library accounts"
                  color="lavender"
                />
                <StatCard
                  label="Currently borrowed"
                  value={active.length}
                  icon={ArrowLeftRight}
                  note={`${overdue.length} overdue item(s)`}
                  color="pink"
                />
              </div>
              <div className="section-head">
                <div>
                  <span className="eyebrow">THE DAILY SHELF</span>
                  <h2>Recently borrowed</h2>
                </div>
                <button
                  className="linkbtn"
                  onClick={() => setTab("Circulation")}
                >
                  See all activity <ArrowUpRight size={15} />
                </button>
              </div>
              <div className="panel">
                <LoanRows
                  loans={loans.slice(0, 4)}
                  bname={bname}
                  mname={mname}
                />
              </div>
              <div className="bottom-grid">
                <div className="panel feature-panel">
                  <div className="section-head inner">
                    <div>
                      <span className="eyebrow">DISCOVER</span>
                      <h2>Staff picks</h2>
                    </div>
                    <button
                      className="linkbtn"
                      onClick={() => setTab("Book collection")}
                    >
                      View catalog <ArrowUpRight size={15} />
                    </button>
                  </div>
                  <div className="pick-grid">
                    {books.slice(0, 3).map((b) => (
                      <BookTile
                        key={b.id}
                        book={b}
                        onClick={() => setModal({ kind: "checkout", book: b })}
                      />
                    ))}
                  </div>
                </div>
                <div className="panel attention">
                  <div className="section-head inner">
                    <div>
                      <span className="eyebrow">FOLLOW UP</span>
                      <h2>Needs attention</h2>
                    </div>
                    <span className="counter">{overdue.length}</span>
                  </div>
                  {overdue.length ? (
                    overdue.map((l) => (
                      <div className="overdue" key={l.id}>
                        <AlertCircle size={17} />
                        <div>
                          <b>{bname(l.bookId)}</b>
                          <small>
                            {mname(l.memberId)} Â· Due {l.due}
                          </small>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="allgood">
                      <CheckCircle2 />
                      <b>Everything is on track</b>
                      <small>No overdue books right now.</small>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
          {tab === "Book collection" && (
            <>
              <PageTitle
                label="THE CATALOG"
                title="Book collection"
                desc="A little something for every curious mind."
                action={
                  <button
                    className="solid"
                    onClick={() => setModal({ kind: "book" })}
                  >
                    <Plus size={16} /> Add a title
                  </button>
                }
              />
              <div className="catalog-tools">
                <div className="search">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Find a title, author, ISBN..."
                  />
                </div>
                <div className="filter">
                  <Filter size={15} />
                  <select
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                  >
                    <option>All</option>
                    {[...new Set(books.map((b) => b.category))].map((x) => (
                      <option>{x}</option>
                    ))}
                  </select>
                </div>
                <button
                  className={`viewbtn ${view === "grid" ? "chosen" : ""}`}
                  onClick={() => setView("grid")}
                >
                  <Grid2X2 size={16} />
                </button>
                <button
                  className={`viewbtn ${view === "list" ? "chosen" : ""}`}
                  onClick={() => setView("list")}
                >
                  <List size={16} />
                </button>
              </div>
              <div
                className={
                  view === "grid" ? "catalog-grid" : "panel catalog-list"
                }
              >
                {filtered.map((b) =>
                  view === "grid" ? (
                    <BookTile
                      key={b.id}
                      book={b}
                      admin
                      onEdit={() => setModal({ kind: "book", item: b })}
                      onDelete={() => {
                        if (confirm(`Delete ${b.title}?`))
                          setBooks((p) => p.filter((x) => x.id !== b.id));
                      }}
                      onClick={() => setModal({ kind: "checkout", book: b })}
                    />
                  ) : (
                    <div className="listbook" key={b.id}>
                      <div className={`cover ${b.color}`}>
                        <BookOpen />
                      </div>
                      <div className="listdetail">
                        <b>{b.title}</b>
                        <small>
                          {b.author} Â· {b.category} Â· {b.isbn}
                        </small>
                      </div>
                      <span>
                        {b.available}/{b.copies} available
                      </span>
                      <button
                        className="iconbutton"
                        onClick={() => setModal({ kind: "book", item: b })}
                      >
                        <Pencil size={15} />
                      </button>
                      <button
                        className="iconbutton"
                        onClick={() =>
                          setBooks((p) => p.filter((x) => x.id !== b.id))
                        }
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  ),
                )}
              </div>
              {!filtered.length && (
                <div className="empty">No books found. Try another search.</div>
              )}
            </>
          )}
          {tab === "Indexing" && (
            <>
              <PageTitle
                label="CATALOG CONTROL"
                title="Book indexing"
                desc="Manage unique accession numbers and locate every title in your collection."
                action={
                  <button
                    className="solid"
                    onClick={() => {
                      let n = books.filter((b) => !b.indexNo).length;
                      setBooks((p) =>
                        p.map((b, i) => ({
                          ...b,
                          indexNo:
                            b.indexNo ||
                            `LIB-${String(i + 1).padStart(4, "0")}`,
                        })),
                      );
                      setToast(
                        n
                          ? `${n} missing index number(s) assigned.`
                          : "All books already have index numbers.",
                      );
                    }}
                  >
                    <ListOrdered size={16} /> Auto-index missing
                  </button>
                }
              />
              <div className="index-summary">
                <div className="index-card">
                  <span className="eyebrow">TOTAL INDEXED TITLES</span>
                  <strong>{books.length}</strong>
                  <small>Unique catalog records</small>
                </div>
                <div className="index-card">
                  <span className="eyebrow">INDEX FORMAT</span>
                  <strong className="index-format">LIB-0001</strong>
                  <small>Prefix + four-digit number</small>
                </div>
                <div className="index-card">
                  <span className="eyebrow">UNIQUE INDEXES</span>
                  <strong>{new Set(books.map((b) => b.indexNo)).size}</strong>
                  <small>Distinct accession codes</small>
                </div>
              </div>
              <div className="catalog-tools">
                <div className="search">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search index number, title, author, ISBN..."
                  />
                </div>
                <span className="counttext">
                  Showing{" "}
                  {
                    books.filter(
                      (b) =>
                        !query ||
                        [b.indexNo, b.title, b.author, b.isbn].some((x) =>
                          (x || "").toLowerCase().includes(query.toLowerCase()),
                        ),
                    ).length
                  }{" "}
                  records
                </span>
              </div>
              <div className="panel">
                <div className="paneltop">
                  <h3>Accession register</h3>
                  <span>Unique book identification</span>
                </div>
                <div className="loanwrap">
                  <table>
                    <thead>
                      <tr>
                        <th>INDEX NUMBER</th>
                        <th>BOOK TITLE</th>
                        <th>AUTHOR</th>
                        <th>ISBN</th>
                        <th>SHELF LOCATION</th>
                        <th>AVAILABILITY</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
                      {books
                        .filter(
                          (b) =>
                            !query ||
                            [
                              b.indexNo,
                              b.title,
                              b.author,
                              b.isbn,
                              b.shelf,
                            ].some((x) =>
                              (x || "")
                                .toLowerCase()
                                .includes(query.toLowerCase()),
                            ),
                        )
                        .sort((a, b) =>
                          (a.indexNo || "").localeCompare(b.indexNo || ""),
                        )
                        .map((b) => (
                          <tr key={b.id}>
                            <td>
                              <span className="indexcode">
                                {b.indexNo || "UNASSIGNED"}
                              </span>
                            </td>
                            <td>
                              <b className="tabletitle">{b.title}</b>
                            </td>
                            <td>{b.author}</td>
                            <td>{b.isbn || "â€”"}</td>
                            <td>{b.shelf || "â€”"}</td>
                            <td>
                              <span
                                className={`tag ${b.available ? "green" : "red"}`}
                              >
                                {b.available} / {b.copies} copies
                              </span>
                            </td>
                            <td>
                              <button
                                className="iconbutton"
                                title="Edit index details"
                                onClick={() =>
                                  setModal({ kind: "book", item: b })
                                }
                              >
                                <Pencil size={15} />
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                  {!books.length && (
                    <div className="empty">No catalog records yet.</div>
                  )}
                </div>
              </div>
              <p className="index-help">
                <ListOrdered size={15} /> Each book receives a unique accession
                number. Use this index number to identify and locate a title
                quickly.
              </p>
            </>
          )}
          {tab === "Members" && (
            <>
              <PageTitle
                label="COMMUNITY"
                title="Library members"
                desc="The readers who make this place feel alive."
                action={session.role === "Administrator" && (
                  <button
                    className="solid"
                    onClick={() => setModal({ kind: "member" })}
                  >
                    <UserPlus size={16} /> Register member
                  </button>
                )}
              />
              <div className="catalog-tools">
                <div className="search">
                  <Search size={17} />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search name, email, member ID..."
                  />
                </div>
                <span className="counttext">{members.length} members</span>
              </div>
              <div className="panel">
                <table>
                  <thead>
                    <tr>
                      <th>MEMBER</th>
                      <th>MEMBER ID</th>
                      <th>JOINED</th>
                      <th>ON LOAN</th>
                      <th>STATUS</th>
                      {session.role === "Administrator" && <th></th>}
                    </tr>
                  </thead>
                  <tbody>
                    {members
                      .filter((m) =>
                        `${m.name} ${m.email} ${m.id}`
                          .toLowerCase()
                          .includes(query.toLowerCase()),
                      )
                      .map((m) => (
                        <tr key={m.id}>
                          <td>
                            <div className="membercell">
                              <div className="avatar">{initials(m.name)}</div>
                              <div>
                                <b>{m.name}</b>
                                <small>{m.email}</small>
                              </div>
                            </div>
                          </td>
                          <td>{m.id}</td>
                          <td>{m.joined}</td>
                          <td>{m.borrowed} books</td>
                          <td>
                            <span className="tag green">Active</span>
                          </td>
                          {session.role === "Administrator" && <td>
                            <button
                              className="iconbutton"
                              onClick={() =>
                                setModal({ kind: "member", item: m })
                              }
                            >
                              <Pencil size={15} />
                            </button>
                          </td>}
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
          {tab === "Circulation" && (
            <>
              <PageTitle
                label="LOAN DESK"
                title="Borrow & return"
                desc="Keep every book moving from one reader to the next."
                action={
                  <button
                    className="solid"
                    onClick={() => setModal({ kind: "checkout" })}
                  >
                    <Plus size={16} /> New checkout
                  </button>
                }
              />
              <div className="metric-grid three">
                <StatCard
                  label="Active loans"
                  value={active.length}
                  icon={ArrowLeftRight}
                  color="green"
                />
                <StatCard
                  label="Overdue"
                  value={overdue.length}
                  icon={Clock3}
                  color="pink"
                />
                <StatCard
                  label="Returned"
                  value={loans.filter((l) => l.status === "Returned").length}
                  icon={CheckCircle2}
                  color="yellow"
                />
              </div>
              <div className="panel">
                <div className="paneltop">
                  <h3>All transactions</h3>
                  <span>{loans.length} records</span>
                </div>
                <LoanRows
                  loans={loans}
                  bname={bname}
                  mname={mname}
                  onReturn={returnBook}
                />
              </div>
            </>
          )}
          {tab === "Insights" && (
            <>
              <PageTitle
                label="LIBRARY PULSE"
                title="Collection insights"
                desc="A closer look at what readers are borrowing."
              />
              <div className="metric-grid">
                <StatCard
                  label="Unique titles"
                  value={books.length}
                  icon={BookOpen}
                  color="green"
                />
                <StatCard
                  label="Total copies"
                  value={copies}
                  icon={LibraryBig}
                  color="yellow"
                />
                <StatCard
                  label="Members"
                  value={members.length}
                  icon={Users}
                  color="lavender"
                />
                <StatCard
                  label="Active loans"
                  value={active.length}
                  icon={ArrowLeftRight}
                  color="pink"
                />
              </div>
              <div className="insightgrid">
                <div className="panel insightpanel">
                  <span className="eyebrow">COLLECTION MIX</span>
                  <h2>Books by category</h2>
                  {[...new Set(books.map((b) => b.category))].map((cat) => (
                    <div className="baritem" key={cat}>
                      <div>
                        <span>{cat}</span>
                        <b>{books.filter((b) => b.category === cat).length}</b>
                      </div>
                      <div className="bar">
                        <i
                          style={{
                            width: `${(books.filter((b) => b.category === cat).length / (books.length || 1)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="panel insightpanel">
                  <span className="eyebrow">AVAILABILITY</span>
                  <h2>Copy status</h2>
                  <div className="bigpercent">
                    {Math.round((available / (copies || 1)) * 100)}
                    <small>%</small>
                  </div>
                  <p className="muted">
                    of all book copies are available to borrow.
                  </p>
                  <div className="bar">
                    <i
                      style={{ width: `${(available / (copies || 1)) * 100}%` }}
                    />
                  </div>
                  <div className="statuslegend">
                    <span>Available: {available}</span>
                    <span>Borrowed: {copies - available}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        <footer>
          <span>
            LEAF LIBRARY <i>Â·</i> LIBRARY WORKSPACE
          </span>
          <span>Made for curious minds.</span>
        </footer>
      </main>
      {modal && (
        <BookModal
          modal={modal}
          books={books}
          members={members}
          close={() => setModal(null)}
          saveBook={saveBook}
          saveMember={saveMember}
          checkout={checkout}
        />
      )}
      {toast && (
        <div className="toast">
          <CheckCircle2 size={17} />
          {toast}
        </div>
      )}
    </div>
  );
}
function PageTitle({ label, title, desc, action }) {
  return (
    <div className="pagetitle">
      <div>
        <span className="eyebrow">{label}</span>
        <h1>{title}</h1>
        <p>{desc}</p>
      </div>
      {action}
    </div>
  );
}
function BookTile({ book, admin, onEdit, onDelete, onClick }) {
  return (
    <article className="booktile">
      <div className={`cover ${book.color}`} onClick={onClick}>
        <div className="coverbrand">LEAF LIBRARY</div>
        <BookOpen size={27} />
        <b>{book.title}</b>
        <small>{book.author}</small>
      </div>
      <div className="tileinfo">
        <div>
          <span className="genre">{book.category}</span>
          <b>{book.title}</b>
          <small>{book.author}</small>
        </div>
        <div className="tilebottom">
          <span className={book.available ? "available" : "unavailable"}>
            {book.available
              ? `${book.available} available`
              : "Currently borrowed"}
          </span>
          <button onClick={onClick}>
            {book.available ? "Borrow" : "Details"} <ArrowUpRight size={13} />
          </button>
        </div>
        {admin && (
          <div className="tileadmin">
            <button onClick={onEdit}>
              <Pencil size={14} /> Edit
            </button>
            <button onClick={onDelete}>
              <Trash2 size={14} /> Delete
            </button>
          </div>
        )}
      </div>
    </article>
  );
}
function LoanRows({ loans, bname, mname, onReturn }) {
  return (
    <div className="loanwrap">
      <table>
        <thead>
          <tr>
            <th>BOOK</th>
            <th>READER</th>
            <th>DATE BORROWED</th>
            <th>DUE DATE</th>
            <th>STATUS</th>
            {onReturn && <th>ACTION</th>}
          </tr>
        </thead>
        <tbody>
          {loans.map((l) => (
            <tr key={l.id}>
              <td>
                <div className="loanbook">
                  <div className="tinycover">
                    <BookOpen size={14} />
                  </div>
                  <div>
                    <b>{bname(l.bookId)}</b>
                    <small>{l.id}</small>
                  </div>
                </div>
              </td>
              <td>{mname(l.memberId)}</td>
              <td>{l.borrowed}</td>
              <td>{l.due}</td>
              <td>
                <span
                  className={`tag ${l.status === "Overdue" ? "red" : l.status === "Returned" ? "green" : "yellow"}`}
                >
                  {l.status}
                </span>
              </td>
              {onReturn && (
                <td>
                  {l.status !== "Returned" && (
                    <button className="return" onClick={() => onReturn(l)}>
                      <RotateCcw size={13} /> Return
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      {!loans.length && <div className="empty">No transactions yet.</div>}
    </div>
  );
}
export default App;


