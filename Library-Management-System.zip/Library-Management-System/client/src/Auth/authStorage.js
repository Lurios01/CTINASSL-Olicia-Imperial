const SESSION_KEY = "leaf-session";
const LEGACY_ACCOUNTS_KEY = "leaf-accounts";
const ADMIN = {
  name: "Librarian",
  email: "admin@gmail.com",
  password: "admin1234!",
  role: "Administrator",
};

export function getSession() {
  localStorage.removeItem(LEGACY_ACCOUNTS_KEY);
  try {
    const session = JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    if (session?.role === "Administrator" && session.email === ADMIN.email) return session;
  } catch {
    // Invalid or outdated session data should send the user to login.
  }
  localStorage.removeItem(SESSION_KEY);
  return null;
}

export function signIn({ email, password }) {
  if (email.trim().toLowerCase() !== ADMIN.email || password !== ADMIN.password) {
    return { error: "Administrator email or password is incorrect." };
  }
  const session = { name: ADMIN.name, email: ADMIN.email, role: ADMIN.role };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  localStorage.removeItem(LEGACY_ACCOUNTS_KEY);
  return { session };
}

export function signOut() {
  localStorage.removeItem(SESSION_KEY);
}
