import { useState } from "react";
import { BookOpen, LibraryBig } from "lucide-react";
import { signIn } from "./authStorage";
import "./auth.css";

function AuthPage({ onAuthenticated }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function submit(event) {
    event.preventDefault();
    setError("");
    const result = signIn({ email, password });
    if (result.error) return setError(result.error);
    onAuthenticated(result.session);
  }

  return (
    <main className="auth-shell">
      <section className="auth-art" aria-label="Leaf Library">
        <div className="auth-brand"><span><LibraryBig size={22} /></span> Leaf Library</div>
        <div className="auth-art-copy">
          <span className="auth-eyebrow">A SPACE FOR EVERY STORY</span>
          <h1>Find your next<br /><em>favorite chapter.</em></h1>
          <p>Your library workspace, ready when you are.</p>
        </div>
        <div className="auth-book-art"><BookOpen size={84} strokeWidth={1} /></div>
        <span className="auth-art-foot">READ · DISCOVER · RETURN</span>
      </section>
      <section className="auth-form-side">
        <div className="auth-form-wrap">
          <span className="auth-mobile-brand"><LibraryBig size={19} /> LEAF LIBRARY</span>
          <span className="auth-eyebrow">LIBRARY WORKSPACE</span>
          <h2>Administrator sign in</h2>
          <p className="auth-intro">Sign in to manage your library workspace.</p>
          <form onSubmit={submit}>
            <label>Administrator email<input type="email" autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Enter your email address" required /></label>
            <label>Password<input type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter administrator password" required /></label>
            {error && <p className="auth-error" role="alert">{error}</p>}
            <button className="auth-submit" type="submit">Sign in</button>
          </form>
          <p className="auth-note">Demo administrator: admin@gmail.com · admin1234!</p>
        </div>
      </section>
    </main>
  );
}

export default AuthPage;
